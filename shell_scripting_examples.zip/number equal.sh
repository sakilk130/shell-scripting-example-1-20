echo "Enter number A:"
read a
echo "Enter number B:"
read b
if [ $a == $b ]
then
echo "Numbers are equals"
else
echo "Numbers are not equal"
fi

