echo "Enter a number:"
read a
echo "Enter a number:"
read b
c=$(( $a + $b ))
echo "Sum is:$c"
